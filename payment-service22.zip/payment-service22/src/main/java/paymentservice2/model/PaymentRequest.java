package paymentservice2.model;



public class PaymentRequest {
    private Long paymentId;  // Payment ID field
    private String itemName;
    private int quantity;
    private double totalPrice;

    // Getter and Setter for paymentId
    public Long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }

    // Existing fields and getters/setters
    public String getItemName() { 
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
}
