package paymentservice2.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;

import paymentservice2.model.PaymentRequest;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    // Enable CORS globally (if desired)
    // You can also define this globally in your Spring configuration class (see below)
    // @CrossOrigin(origins = "http://localhost:4200")

    // Enable CORS for this specific endpoint
    @CrossOrigin(origins = "http://localhost:4200")  // Allow requests from Angular frontend
    @GetMapping("/methods")
    public List<String> getPaymentMethods() {
        return Arrays.asList("PhonePe", "Google Pay", "Paytm", "Amazon Pay");
    }

    // Enable CORS for this specific endpoint
    @CrossOrigin(origins = "http://localhost:4200")  // Allow requests from Angular frontend
    @PostMapping("/process")
    public String processPayment(@RequestBody PaymentRequest paymentRequest) {
        // Simulate payment processing by printing out payment details
        System.out.println("Processing payment for: " + paymentRequest.getItemName());

        // Simulate generating a paymentId (using current time as an example)
        long paymentId = System.currentTimeMillis();  // Use current time as a mock paymentId
        paymentRequest.setPaymentId(paymentId);

        // Return mock payment response
        return "Payment processed successfully. Payment ID: " + paymentId + " for item: " + paymentRequest.getItemName();
    }
}
