package paymentservice2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentService22Application {

	public static void main(String[] args) {
		SpringApplication.run(PaymentService22Application.class, args);
	}

}
