package orderservice2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import orderservice2.model.Order;
import orderservice2.repository.OrderRepository;



import java.util.List;

@Service

public class OrderService {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private OrderRepository orderRepository;

    // Create order and return available payment methods
    public String createOrder(Order order) {
        // Generate the orderId first (or use a more appropriate ID generation strategy)
        
        // Save order to the database after setting orderId
        orderRepository.save(order);

        // Get the available payment methods from the Payment Service
        List<String> paymentMethods = getPaymentMethods();

        // Return a message indicating the order creation and available payment methods
        return "Order created for item: " + order.getItemName() + ". Available payment methods: " + paymentMethods;
    }

    // Get available payment methods from the Payment Service
    private List<String> getPaymentMethods() {
        // Assuming the Payment Service is running on localhost:8081
        String paymentUrl = "http://localhost:8081/payment/methods";
        
        // Call the Payment Service to get available payment methods
        // Safe deserialization to List<String>
        List<String> paymentMethods = restTemplate.getForObject(paymentUrl, List.class);
        
        return paymentMethods;
    }

    // Get all orders from the database
    public Iterable<Order> getAllOrders() {
        return orderRepository.findAll();
    }

	public Order getOrderById(Long orderId) {
		// TODO Auto-generated method stub
		return null;
	}
}