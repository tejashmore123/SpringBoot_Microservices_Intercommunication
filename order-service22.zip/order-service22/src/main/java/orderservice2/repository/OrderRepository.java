package orderservice2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import orderservice2.model.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {
}
