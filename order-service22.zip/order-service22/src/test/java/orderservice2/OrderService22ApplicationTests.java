package orderservice2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderService22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
